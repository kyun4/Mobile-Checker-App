package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AddStudentsToSection extends AppCompatActivity {

    List<Students> lstStudents = new ArrayList<>();
    ArrayList<Students> lstStudentsInSection = new ArrayList<>();

    List<SectionStudent> lstSectionStudent = new ArrayList<>();

    Button btnBack;

    public static int section_id = 0;

    StudentAdapter studAdapter;

    Spinner studspinner;
    ListView students_in_section_listview;

    public static String section_name = null;
    public static String section_course = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_students_to_section);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        section_id = intent.getIntExtra("section_id",0);

        studspinner = (Spinner) findViewById(R.id.studentspinner);
        students_in_section_listview = (ListView) findViewById(R.id.list_students_to_section);
        btnBack = (Button) findViewById(R.id.btnBack);

        DBHandler db = new DBHandler(this);

        toolbar.setSubtitle(section_course+" "+section_name);

        lstStudents = db.getAllStudents();

        lstSectionStudent = db.getAllSectionStudents();

        final List<String> lstStud_tospinner = new ArrayList<String>();

        lstStud_tospinner.clear();

        lstStud_tospinner.add("-- Student List --");

        for(Students stud:lstStudents)
        {
            lstStud_tospinner.add(""+stud.getLastname()+", "+stud.getFirstname()+" "+stud.getExt()+" "+stud.getMiddlename()+"");
        }

        ArrayAdapter<String> student_spinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lstStud_tospinner);
        student_spinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        studspinner.setAdapter(student_spinner);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        lstStudentsInSection.clear();

        for(SectionStudent secstud:lstSectionStudent)
        {

            if(secstud.getSection_id() == section_id)
            {

                List<Students> student_info = new ArrayList<>();
                student_info = db.getStudent(secstud.getStudent_id());

                String sn = "";
                String fname = "";
                String mname = "";
                String lname = "";
                String ext = "";
                int courseid = 1;

                sn = student_info.get(0).getStudent_number();
                fname = student_info.get(0).getFirstname();
                mname = student_info.get(0).getMiddlename();
                lname = student_info.get(0).getLastname();
                ext = student_info.get(0).getExt();
                courseid = student_info.get(0).getCourse();

                lstStudentsInSection.add(new Students(secstud.getStudent_id(),sn,courseid,fname,mname,lname,ext));

            }

        }

        studAdapter = new StudentAdapter(this, R.layout.list_item_student, lstStudentsInSection);
        students_in_section_listview.setAdapter(studAdapter);

        AdapterView.OnItemLongClickListener deletestudent_fromsection = new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l){

                final int pos = i;
                final CharSequence[] items = {"Delete","Cancel"};

                new AlertDialog.Builder(AddStudentsToSection.this).setTitle("Students List in this Section").setItems(items, new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int item)
                    {
                        if(item == 0)
                        {

                            Students stud = lstStudentsInSection.get(pos);

                            DBHandler dbs = new DBHandler(AddStudentsToSection.this);

                            studAdapter.remove(studAdapter.getItem(pos));
                            studAdapter.notifyDataSetChanged();

                            dbs.deleteSectionStudent("" + section_id + "", "" + stud.getID() + "");

                            notificationAlert("Student List in Class","1 Student Removed", "OK");

                        }
                        else if(item == 1)
                        {
                            dialog.dismiss();
                        }
                    }

                }).show();

                return false;
            }
        };

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (studspinner.getSelectedItem().toString().trim().equals("-- Student List --")) {
                    Toast.makeText(getApplicationContext(), "Please specify a student to add in this Section/Class", Toast.LENGTH_SHORT).show();
                } else {

                    DBHandler db = new DBHandler(AddStudentsToSection.this);

                    int studentid = lstStudents.get(studspinner.getSelectedItemPosition() - 1).getID();

                    db.addSectionStudent(new SectionStudent(1, studentid, section_id));


                    lstSectionStudent = db.getAllSectionStudents();

                    lstStudentsInSection.clear();

                    for (SectionStudent secstud : lstSectionStudent) {

                        if (secstud.getSection_id() == section_id) {
                            List<Students> student_info = new ArrayList<>();
                            student_info = db.getStudent(secstud.getStudent_id());

                            String sn = "";
                            String fname = "";
                            String mname = "";
                            String lname = "";
                            String ext = "";
                            int courseid = 1;

                            sn = student_info.get(0).getStudent_number();
                            fname = student_info.get(0).getFirstname();
                            mname = student_info.get(0).getMiddlename();
                            lname = student_info.get(0).getLastname();
                            ext = student_info.get(0).getExt();
                            courseid = student_info.get(0).getCourse();

                            lstStudentsInSection.add(new Students(secstud.getStudent_id(),sn,courseid,fname,mname,lname,ext));
                        }
                    }

                    studAdapter.notifyDataSetChanged();
                }

            }
        });

        students_in_section_listview.setOnItemLongClickListener(deletestudent_fromsection);
    }

    public void notificationAlert(String title, String msg, String bottomAlert)
    {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

}
