package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/19/2017.
 */
public class Subjects  {


    private int ID;
    private String subject_code;
    private String subject_description;
    private int subject_nounits;


    public Subjects()
    {


    }

    public Subjects(int ID, String subject_code, String subject_description, int subject_nounits)
    {

        this.ID = ID;
        this.subject_nounits = subject_nounits;
        this.subject_description = subject_description;
        this.subject_code = subject_code;
    }

    public int getSubject_nounits() {
        return subject_nounits;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setSubject_nounits(int subject_nounits) {
        this.subject_nounits = subject_nounits;
    }

    public String getSubject_code() {
        return subject_code;
    }

    public void setSubject_code(String subject_code) {
        this.subject_code = subject_code;
    }


    public String getSubject_description() {
        return subject_description;
    }

    public void setSubject_description(String subject_description) {
        this.subject_description = subject_description;
    }




}
