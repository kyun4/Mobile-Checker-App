package com.example.kyun.mobilechecker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/27/2017.
 */
public class SectionAdapter extends ArrayAdapter<Sections> {

    Context context;
    List<Sections> lst;

    public SectionAdapter(Context context, int resourceid, ArrayList<Sections> obj)
    {
        super(context,resourceid,obj);
        this.context = context;
        this.lst = obj;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = convertView;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.list_item_section, null);

        Sections sec = lst.get(position);

        TextView txtSectionName = (TextView) v.findViewById(R.id.txtsectionname);
        TextView txtSectionCourse = (TextView) v.findViewById(R.id.txtsectioncourse);

        txtSectionName.setText(sec.getSection_name().toString());

        DBHandler db = new DBHandler(getContext());

        List<Course> crs = db.getCourse(sec.getSection_course());

        txtSectionCourse.setText(crs.get(0).getCourse_abbrev());

        return v;
    }


}
