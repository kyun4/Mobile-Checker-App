package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/27/2017.
 */
public class Sections {

    private int ID;
    private String section_name;
    private int section_course;

    public Sections(int ID, String section_name,int section_course)
    {
        this.ID = ID;
        this.section_name = section_name;
        this.section_course = section_course;
    }

    public int getSection_course() {
        return section_course;
    }

    public void setSection_course(int section_course) {
        this.section_course = section_course;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Sections()
    {
    

    }

    public String getSection_name() {
        return section_name;
    }

    public void setSection_name(String section_name) {
        this.section_name = section_name;
    }
}
