package com.example.kyun.mobilechecker;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Environment;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellRange;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StudentsActivity extends AppCompatActivity {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */


    public static File file = null;
    public static String subjectcode = "";
    public static String subjectdesc = "";
    public static String subjectcourseyearsection = "";

    public static int section_id = 0;
    public static int subject_id = 0;

    public static String section = "";
    public static String course = "";

    public static ArrayList<Students> lstStudents = new ArrayList<Students>();
    public static ArrayList<StudentsOutput> lstStudentsOutput = new ArrayList<StudentsOutput>();

    private SectionsPagerAdapter mSectionsPagerAdapter;

    public static Functions func = new Functions();

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        Intent intent = getIntent();
        subject_id = intent.getIntExtra("subject_id",0);
        section_id = intent.getIntExtra("section_id",0);

        subjectcode = intent.getStringExtra("subjectcode");
        subjectdesc = intent.getStringExtra("subjectdesc");
        section = intent.getStringExtra("section_name");
        course = intent.getStringExtra("course_abbrev");
        subjectcourseyearsection = intent.getStringExtra("cys");

        toolbar.setSubtitle(subjectcode + " " + subjectdesc);

       DBHandler db = new DBHandler(this);

        loadStudents(db,subject_id);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StudentsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }



    public void loadStudents(DBHandler db, int subject_id)
    {

        List<Students> lst = db.getAllStudents();
        List<SectionStudent> lstsecstud = db.getAllSectionStudents();

        lstStudents.clear();

        for(Students stud:lst)
        {
            for(SectionStudent secstud:lstsecstud)
            {

                if(secstud.getSection_id() == section_id)
                {
                    if(secstud.getStudent_id() == stud.getID())
                    {
                        lstStudents.add(new Students(stud.getID(), stud.getStudent_number(), stud.getCourse(), stud.getFirstname(), stud.getMiddlename(),stud.getLastname(), stud.getExt()));

                    }

                }

            }

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mainstudents, menu);



        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        else  if (id == R.id.action_excelgen) {

            if(saveExcelFile(this,""+course+" "+section+" - "+subjectdesc+" ("+subjectcode+").xlsx","CLASS RECORD") == true)
            {
                func.notificationAlert("Excel Generated Successfully","File saved on "+file+"","OK",this);
            }

            return true;
        }
        else if(id == R.id.home)
        {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        public PlaceholderFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;


        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {

            View rootView = inflater.inflate(R.layout.fragment_students, container, false);

            TextView txtInstruction = (TextView) rootView.findViewById(R.id.txtinstruction);
            ListView lstviewStudents = (ListView) rootView.findViewById(R.id.list_students);

            if(getArguments().getInt(ARG_SECTION_NUMBER) == 1)
            {
                txtInstruction.setText("");
                StudentAdapterFragment studAdapter = new StudentAdapterFragment(getContext(), R.layout.list_item_student, lstStudents);
                lstviewStudents.setAdapter(studAdapter);
            }
            else if(getArguments().getInt(ARG_SECTION_NUMBER) == 2)
            {
                txtInstruction.setText("Switch icon on left side to mark as Absent/Present");
                StudentAdapterAttendance studAdapter = new StudentAdapterAttendance(getContext(), R.layout.list_item_student_attendance, lstStudents);
                lstviewStudents.setAdapter(studAdapter);
            }
            else if(getArguments().getInt(ARG_SECTION_NUMBER) == 3)
            {

                txtInstruction.setText("");
                StudentOutputAdapter studAdapter = new StudentOutputAdapter(getContext(), R.layout.list_item_student_output, lstStudents);
                lstviewStudents.setAdapter(studAdapter);

            }

            return rootView;
        }
    }



    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "All";
                case 1:
                    return "Attendance";
                case 2:
                    return "Output";
            }
            return null;
        }
    }


    public static boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    public static boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    private static boolean saveExcelFile(Context context, String fileName, String sheetname) {

        // check if available and not read only
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) {
           func.msgshort(context,"External Storage Unavailable");
            return false;
        }

        boolean success = false;

        //New Workbook
        Workbook wb = new HSSFWorkbook();

        Cell c = null;

        //Cell style for header row
        CellStyle cs = wb.createCellStyle();
        cs.setFillForegroundColor(HSSFColor.YELLOW.index);
        cs.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        CellStyle alignedText = wb.createCellStyle();
        cs.setAlignment(CellStyle.ALIGN_CENTER);
        cs.setVerticalAlignment(CellStyle.ALIGN_FILL);


        //New Sheet
        Sheet sheet1 = null;
        sheet1 = wb.createSheet(""+sheetname+"");

        // Generate column heading

        Row row = sheet1.createRow(0);
        c = row.createCell(10);
        c.setCellValue("TAGUIG CITY UNIVERSITY");
        c.setCellStyle(alignedText);

        Row r1 = sheet1.createRow(1);
        c = r1.createCell(10);
        c.setCellValue("Class Record");
        c.setCellStyle(alignedText);

        Object[][] headercontent = {

                {"INSTRUCTOR:","Reynaldo G Alvez"},
                {"COURSE CODE:",""+subjectcode+""},
                {"COURSE DESCRIPTION:",""+subjectdesc+""},
                {"COURSE/YEAR/SECTION:",""+subjectcourseyearsection+""}

        };



        int numRow = 2;

        for(Object[] dataHeader:headercontent)
        {
            Row rrr = sheet1.createRow(numRow++);

            int colnum = 1;

            for(Object dhval:dataHeader)
            {
                c = rrr.createCell(colnum++);
                if(dhval instanceof String)
                {
                    c.setCellValue((String) dhval);
                }
                else   if(dhval instanceof Integer)
                {
                    c.setCellValue((Integer) dhval);
                }
            }

            for(Object dhval:dataHeader)
            {
                c = rrr.createCell(3);
                if(dhval instanceof String)
                {
                    c.setCellValue((String) dhval);
                }
                else   if(dhval instanceof Integer)
                {
                    c.setCellValue((Integer) dhval);
                }
            }

        }

        Row rr = sheet1.createRow(6);

        int r = 0;

        for(int col = 0;col<=51;col++)
        {
            c = rr.createCell(col);
            c.setCellStyle(cs);

            if(r == 3)
            {
                c.setCellValue("************************MIDTERM PERIOD CLASS RECORD************************");
                sheet1.setColumnWidth(col, (20 * 500));
                r = 0;
            }

            r++;
        }

        Object[] headername = {

                "STUDENT #","LASTNAME","FIRSTNAME","MI"
        };



        Row r3 = sheet1.createRow(7);
        c = r3.createCell(1);
        c.setCellValue("NAMES");

        int numcol = 1;
        Row r4 = sheet1.createRow(8);

        for(Object hName:headername)
        {

            c = r4.createCell(numcol++);

            if(hName instanceof  String)
            {
                c.setCellValue((String) hName);
            }
            else if(hName instanceof Integer)
            {
                c.setCellValue((Integer) hName);
            }

        }

        int studrow = 9;
        int recrow = 0;

        for(Object stud:lstStudents)
        {
            Row r5 = sheet1.createRow(studrow++);

            c = r5.createCell(0);
            c.setCellValue(recrow + 1);

            c = r5.createCell(1);
            c.setCellValue(""+lstStudents.get(recrow).getStudent_number().toString().toUpperCase()+"");

            c = r5.createCell(2);
            c.setCellValue(""+lstStudents.get(recrow).getLastname().toString().toUpperCase()+"");

            c = r5.createCell(3);
            c.setCellValue(""+lstStudents.get(recrow).getFirstname().toString().toUpperCase()+"");

            c = r5.createCell(4);
            c.setCellValue(""+lstStudents.get(recrow).getMiddlename().toString().substring(0,1).toUpperCase()+".");


            recrow++;
        }


        sheet1.addMergedRegion(new CellRangeAddress(2,2,1,2));
        sheet1.addMergedRegion(new CellRangeAddress(3,3,1,2));
        sheet1.addMergedRegion(new CellRangeAddress(4,4,1,2));
        sheet1.addMergedRegion(new CellRangeAddress(5,5,1,2));
        sheet1.addMergedRegion(new CellRangeAddress(7,7,1,3));


        sheet1.setColumnWidth(0, 600);
        sheet1.setColumnWidth(1, (12 * 350));
        sheet1.setColumnWidth(2, (12 * 350));
        sheet1.setColumnWidth(3, (12 * 500));

        sheet1.setColumnWidth(10, (20 * 500));

        // Create a path where we will place our List of objects on external storage
        file = new File(context.getExternalFilesDir(null), fileName);
        FileOutputStream os = null;

        try {
            os = new FileOutputStream(file);
            wb.write(os);

            success = true;
        } catch (IOException e) {
            Toast.makeText(context, "Error Writing "+e, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(context, "Failed to Save File"+e, Toast.LENGTH_SHORT).show();
        } finally {
            try {
                if (null != os)
                    os.close();
            } catch (Exception ex) {
            }
        }

        return success;
    }


}
