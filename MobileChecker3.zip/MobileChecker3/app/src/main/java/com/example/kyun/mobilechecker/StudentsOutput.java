package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/19/2017.
 */
public class StudentsOutput {


    private String student_number;
   private int output_type;
   private int output_item;
   private int output_score;
   private int ID;

    public int getOutput_item() {
        return output_item;
    }

    public void setOutput_item(int output_item) {
        this.output_item = output_item;
    }

    public int getOutput_score() {
        return output_score;
    }

    public void setOutput_score(int output_score) {
        this.output_score = output_score;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public StudentsOutput()
    {

    }

    public StudentsOutput(int ID, String student_number, int output_type, int output_item,int output_score)
    {
        this.ID = ID;
        this.output_type = output_type;
        this.output_item = output_item;
        this.output_score = output_score;
    }

    public String getStudent_number() {
        return student_number;
    }

    public void setStudent_number(String student_number) {
        this.student_number = student_number;
    }

    public int getOutput_type() {
        return output_type;
    }

    public void setOutput_type(int output_type) {
        this.output_type = output_type;
    }
}
