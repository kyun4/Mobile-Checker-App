package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/30/2017.
 */
public class SubjectStudent {

    private static int ID;
    private static int student_id;
    private static int subject_id;

    public SubjectStudent(int ID, int student_id, int subject_id)
    {
        this.ID = ID;
        this.student_id = student_id;
        this.subject_id = subject_id;
    }

    public SubjectStudent()
    {

    }

    public static int getID() {
        return ID;
    }

    public static void setID(int ID) {
        SubjectStudent.ID = ID;
    }

    public static int getStudent_id() {
        return student_id;
    }

    public static void setStudent_id(int student_id) {
        SubjectStudent.student_id = student_id;
    }

    public static int getSubject_id() {
        return subject_id;
    }

    public static void setSubject_id(int subject_id) {
        SubjectStudent.subject_id = subject_id;
    }
}
