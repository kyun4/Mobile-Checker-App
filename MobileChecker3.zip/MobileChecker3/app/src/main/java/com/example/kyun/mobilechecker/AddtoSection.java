package com.example.kyun.mobilechecker;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class AddtoSection extends AppCompatActivity {

    ListView lst;
    Button btnBack;
    ArrayList<Sections> lstSections = new ArrayList<Sections>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addto_section);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lst = (ListView) findViewById(R.id.listSections);
        btnBack = (Button) findViewById(R.id.btnBack);

        List<Sections> lstsec = new ArrayList<Sections>();

        DBHandler db = new DBHandler(this);
        lstsec = db.getAllSections();

        lstSections.clear();

        for(Sections secs:lstsec)
        {
            lstSections.add(new Sections(secs.getID(),secs.getSection_name(),secs.getSection_course()));
        }


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        SectionAdapter secAdapter = new SectionAdapter(this, R.layout.list_item_section,lstSections);
        lst.setAdapter(secAdapter);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

}
