package com.example.kyun.mobilechecker;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.Subject;

public class SectionSubjectActivity extends AppCompatActivity {


    ListView lst;

    // for listview adapter only
    ArrayList<Subjects> lstsubjects = new ArrayList<Subjects>();

    public static int section_id = 0;
    public static int course_id = 0;

    public static String section_name = null;
    public static String course_abbrev = null;

    public static String subjectcode = null;
    public static String subjectdesc = null;
    public static String cys = null;

    public static Functions func = new Functions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_subject);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lst = (ListView) findViewById(R.id.list_subject_from_section);

        Intent intent = getIntent();
        section_id = intent.getIntExtra("section_id", 0);
        course_id = intent.getIntExtra("course_id", 0);

        section_name = func.getSectionNameById(this, section_id);
        course_abbrev = func.getCourseAbbrevById(this, course_id);

        DBHandler db = new DBHandler(this);

        List<SectionSubject> secsub = new ArrayList<>();
        secsub = db.getAllSectionSubject();

        List<Sections> section_info = db.getSection(section_id);
        List<Course> course_info = db.getCourse(course_id);

        toolbar.setSubtitle(course_info.get(0).getCourse_abbrev()+" "+section_info.get(0).getSection_name());
        cys = course_info.get(0).getCourse_abbrev() + " "+section_info.get(0).getSection_name();

        List<Subjects> subject_info = db.getAllSubjects();


        String subj_desc = "";
        String subj_code = "";
        int subject_nounits = 0;


        for(SectionSubject subjs:secsub)
        {

            if(subjs.getSection_id() == section_id)
            {

                for(Subjects sub:subject_info)
                {
                    if(subjs.getSubject_id() == sub.getID())
                    {
                        subj_desc = sub.getSubject_description();
                        subj_code  = sub.getSubject_code();
                        subject_nounits = sub.getSubject_nounits();
                    }
                }

                lstsubjects.add(new Subjects(subjs.getID(),""+subj_code+"",""+subj_desc+"",subject_nounits));
            }


        }

        AdapterView.OnItemClickListener clicksubject = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), StudentsActivity.class);

                Subjects subj = lstsubjects.get(i);

                subjectcode = subj.getSubject_code();
                subjectdesc = subj.getSubject_description();

                intent.putExtra("subject_id",subj.getID());
                intent.putExtra("section_id",section_id);
                intent.putExtra("section_name",section_name);
                intent.putExtra("subjectcode",subjectcode);
                intent.putExtra("subjectdesc",subjectdesc);
                intent.putExtra("course_abbrev",course_abbrev);
                intent.putExtra("cys",cys);

                startActivity(intent);
            }
        };

        SubjectAdapter subjectAdapter = new SubjectAdapter(this, R.layout.item_subjects, lstsubjects);
        lst.setAdapter(subjectAdapter);
        lst.setOnItemClickListener(clicksubject);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view)
            {

              Intent intent = new Intent(SectionSubjectActivity.this, MainActivity.class);
              startActivity(intent);

            }
        });
    }

}
