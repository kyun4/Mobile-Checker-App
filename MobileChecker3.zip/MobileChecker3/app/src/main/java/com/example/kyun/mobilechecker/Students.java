package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/26/2017.
 */
public class Students {

    private String student_number;
    private int course;
    private String firstname;
    private String lastname;
    private String middlename;
    private String ext;
    private int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Students()
    {

    }

    public Students(int ID, String student_number, int course, String firstname, String middlename, String lastname, String ext)
    {
        this.ID = ID;
        this.student_number=student_number;
        this.course = course;
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.ext = ext;
    }


    public String getStudent_number() {
        return student_number;
    }

    public void setStudent_number(String student_number) {
        this.student_number = student_number;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }
}
