package com.example.kyun.mobilechecker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/19/2017.
 */
public class StudentOutputAdapter extends ArrayAdapter<Students> {

    Context context;
    List<Students> lstStudents;

    public StudentOutputAdapter(Context context, int resourceid, ArrayList<Students> objects)
    {

        super(context, resourceid, objects);
        this.context = context;
        this.lstStudents = objects;

    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = convertView;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.list_item_student_output, null);

        Students sList = lstStudents.get(position);

        TextView txtFullname = (TextView) v.findViewById(R.id.txtfullname);
        TextView txtStudentNumber = (TextView) v.findViewById(R.id.txtstudentnumber);
        TextView txtOutput = (TextView) v.findViewById(R.id.txtOutput);

        for(StudentsOutput lst:StudentsActivity.lstStudentsOutput)
        {
            String outputstr = "";

            if(lst.getStudent_number().toString().contains(sList.getStudent_number().toString().trim()))
            {



                txtOutput.setText(outputstr);
            }
        }


        String fullname = String.valueOf(sList.getLastname().toString().toUpperCase()+", "+sList.getFirstname().toString()+" "+sList.getMiddlename().toString()+" "+sList.getExt().toString()+"");

        txtFullname.setText(fullname);
        txtStudentNumber.setText(sList.getStudent_number().toString());



        return v;
    }

}
