package com.example.kyun.mobilechecker;

import java.util.Date;

/**
 * Created by kyun on 10/7/2017.
 */
public class Attendance {

    public Attendance()
    {

    }

    public Attendance(int SectionSubject_id, int student_id, Date classDate)
    {

    }
}
