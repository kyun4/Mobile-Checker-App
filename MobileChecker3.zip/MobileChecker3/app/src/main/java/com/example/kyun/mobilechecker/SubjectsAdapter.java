package com.example.kyun.mobilechecker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/27/2017.
 */
public class SubjectsAdapter extends ArrayAdapter<Subjects> {

    Context context;
    List<Subjects> lst;

    public SubjectsAdapter(Context context, int resourceid, ArrayList<Subjects> obj)
    {
        super(context,resourceid,obj);

        this.context = context;
        this.lst = obj;
    }

    public View getView(int position, View view, ViewGroup parent)
    {
        View v = view;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.item_subjects,null);

        Subjects subj = lst.get(position);

        TextView txtSubjectDesc = (TextView) v.findViewById(R.id.txtsubjectdesc);
        TextView txtSubjectCode = (TextView) v.findViewById(R.id.txtsubjectcode);

        txtSubjectDesc.setText(""+subj.getSubject_description().toString()+"");
        txtSubjectCode.setText(""+subj.getSubject_code().toString()+"");

        return v;
    }


}
