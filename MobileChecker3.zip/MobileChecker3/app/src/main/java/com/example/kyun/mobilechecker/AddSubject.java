package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AddSubject extends AppCompatActivity {

    public static int subjectnounits = 1;
    public static String subjectabbrev = "";
    public static String subjectdesc = "";

    EditText txtSubjectDescription = null;
    EditText txtSubjectAbbrev = null;
    EditText txtSubjectNoUnits = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subject);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button btn = (Button) findViewById(R.id.btnBack);

        txtSubjectDescription = (EditText) findViewById(R.id.txtSubjectDesc);
        txtSubjectAbbrev = (EditText) findViewById(R.id.txtSubjectAbbrev);
        txtSubjectNoUnits = (EditText) findViewById(R.id.txtSubjectNoUnits);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddSubject.this, MainActivity.class);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(txtSubjectAbbrev.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddSubject.this, "Subject Code is Empty", Toast.LENGTH_SHORT).show();
                }
                else if(txtSubjectDescription.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddSubject.this, "Subject Description is Empty", Toast.LENGTH_SHORT).show();
                }
                else if(txtSubjectNoUnits.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddSubject.this, "No. of Unit(s) is empty", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    subjectabbrev = txtSubjectAbbrev.getText().toString().trim();
                    subjectdesc = txtSubjectDescription.getText().toString();
                    subjectnounits = Integer.parseInt(txtSubjectNoUnits.getText().toString());

                    DBHandler db = new DBHandler(AddSubject.this);

                    db.addSubject(new Subjects(1,subjectabbrev,subjectdesc,subjectnounits));

                    notificationAlert(" (" + subjectabbrev + ") - " + subjectdesc + "", "1 Subject Added", "OK");

                    txtSubjectAbbrev.setText("");
                    txtSubjectDescription.setText("");
                    txtSubjectNoUnits.setText("");

                }


            }
        });
    }

    public void notificationAlert(String title, String msg, String bottomAlert)
    {

        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

}
