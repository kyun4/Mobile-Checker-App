package com.example.kyun.mobilechecker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.apache.poi.hpsf.Section;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/29/2017.
 */
public class SectionSubjectAdapter extends ArrayAdapter<SectionSubject> {

    Context ctx;
    List<SectionSubject> lst;

    public SectionSubjectAdapter(Context context, int resourceid, ArrayList<SectionSubject> obj)
    {
        super(context, resourceid, obj);
        this.ctx = context;
        this.lst = obj;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = convertView;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.item_subjects,null);

        SectionSubject secsub = lst.get(position);

        TextView txtsubjectdesc = (TextView) v.findViewById(R.id.txtsubjectdesc);
        TextView txtsubjectcode = (TextView) v.findViewById(R.id.txtsubjectcode);





        return v;
    }
}
