package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/28/2017.
 */
public class Course {

    private static int ID;
    private static int maxyear;
    private static String course_desc;
    private static String course_abbrev;


    public Course(int ID, String course_desc, String course_abbrev, int maxyear)
    {
        this.ID = ID;
        this.maxyear = maxyear;
        this.course_desc = course_desc;
        this.course_abbrev = course_abbrev;
    }

    public Course()
    {


    }

    public static int getID() {
        return ID;
    }

    public static void setID(int ID) {
        Course.ID = ID;
    }

    public static int getMaxyear() {
        return maxyear;
    }

    public static void setMaxyear(int maxyear) {
        Course.maxyear = maxyear;
    }

    public static String getCourse_desc() {
        return course_desc;
    }

    public static void setCourse_desc(String course_desc) {
        Course.course_desc = course_desc;
    }

    public static String getCourse_abbrev() {
        return course_abbrev;
    }

    public static void setCourse_abbrev(String course_abbrev) {
        Course.course_abbrev = course_abbrev;
    }
}
