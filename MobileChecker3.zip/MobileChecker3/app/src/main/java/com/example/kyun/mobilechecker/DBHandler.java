package com.example.kyun.mobilechecker;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.apache.poi.hpsf.Section;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/25/2017.
 */
public class DBHandler extends SQLiteOpenHelper {

   private static int DATABASE_VERSION = 1116;
   private static String DATABASE_NAME = "mobile_checker";

   private static String TABLE_STUDENT = "tbl_students";
   private static String TABLE_SUBJECT = "tbl_subjects";
   private static String TABLE_SECTION = "tbl_sections";
   private static String TABLE_COURSE = "tbl_course";
   private static String TABLE_SECTIONSUBJECT = "tbl_sectionsubject";
   private static String TABLE_SECTIONSTUDENT = "tbl_sectionstudent";
   private static String TABLE_SUBJECTSTUDENT = "tbl_subjectstudent";
   private static String TABLE_ATTENDANCE = "tbl_attendance";

   private static String KEY_ID = "id";

   private static String FNAME = "firstname";
   private static String MNAME = "middlename";
   private static String LNAME = "lastname";
   private static String EXT = "ext";
   private static String STUDENT_NUMBER = "studentnumber";
   private static String COURSE = "course";

   private static String SUBJECT_CODE = "code";
   private static String SUBJECT_DESCRIPTION = "description";
   private static String SUBJECT_NOUNITS = "nounits";

   private static String SECTION_NAME = "section_name";
   private static String SECTION_COURSE = "section_course";

    private static String COURSE_DESC = "course_desc";
    private static String COURSE_ABBREV = "course_abbrev";
    private static String COURSE_MAXYEAR = "course_maxyear";

    private static String SECTIONSUBJECT_SCHEDULEDAYS = "scheduledays";
    private static String SECTIONSUBJECT_COURSEID = "course_id";
    private static String SECTIONSUBJECT_SECTIONID = "section_id";
    private static String SECTIONSUBJECT_SUBJECTID = "subject_id";

    private static String SECTIONSTUDENT_SECTIONID = "section_id";
    private static String SECTIONSTUDENT_STUDENTID = "student_id";

    private static String SUBJECTSTUDENT_STUDENTID = "student_id";
    private static String SUBJECTSTUDENT_SUBJECTID = "subject_id";

    private static String ATTENDANCE_SECTIONSUBJECTID = "sectionsubject_id";
    private static String ATTENDANCE_STUDENTID = "student_id";
    private static String ATTENDANCE_DATECLASS = "classdate";

   public DBHandler(Context context)
   {
       super(context, DATABASE_NAME, null, DATABASE_VERSION);
   }

    @Override

    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_TABLE_STUDENT = "CREATE TABLE "+TABLE_STUDENT+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+FNAME+" TEXT,"+MNAME+" TEXT,"+LNAME+" TEXT,"+EXT+" TEXT,"+STUDENT_NUMBER+" TEXT,"+COURSE+" TEXT)";
        String CREATE_TABLE_SUBJECT = "CREATE TABLE "+TABLE_SUBJECT+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+SUBJECT_CODE+" TEXT,"+SUBJECT_DESCRIPTION+" TEXT,"+SUBJECT_NOUNITS+" INTEGER)";
        String CREATE_TABLE_SECTION = "CREATE TABLE "+TABLE_SECTION+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+SECTION_NAME+" TEXT,"+SECTION_COURSE+" INTEGER)";
        String CREATE_TABLE_COURSE = "CREATE TABLE "+TABLE_COURSE+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+COURSE_DESC+" TEXT,"+COURSE_ABBREV+" TEXT,"+COURSE_MAXYEAR+" INTEGER)";
        String CREATE_TABLE_SECTIONSUBJECT = "CREATE TABLE "+TABLE_SECTIONSUBJECT+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+SECTIONSUBJECT_COURSEID+" INTEGER,"+SECTIONSUBJECT_SCHEDULEDAYS+" TEXT,"+SECTIONSUBJECT_SECTIONID+" INTEGER,"+SECTIONSUBJECT_SUBJECTID+" INTEGER)";
        String CREATE_TABLE_SECTIONSTUDENT = "CREATE TABLE "+TABLE_SECTIONSTUDENT+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+SECTIONSTUDENT_STUDENTID+" INTEGER,"+SECTIONSTUDENT_SECTIONID+" INTEGER)";
        String CREATE_TABLE_SUBJECTSTUDENT = "CREATE TABLE "+TABLE_SUBJECTSTUDENT+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+SUBJECTSTUDENT_STUDENTID+" INTEGER,"+SUBJECTSTUDENT_SUBJECTID+" INTEGER)";
        String CREATE_TABLE_ATTENDANCE = "CREATE TABLE "+TABLE_ATTENDANCE+" ("+KEY_ID+" INTEGER PRIMARY KEY,"+ATTENDANCE_SECTIONSUBJECTID+" INTEGER,"+ATTENDANCE_STUDENTID+" INTEGER)";

        db.execSQL(CREATE_TABLE_STUDENT);
        db.execSQL(CREATE_TABLE_SUBJECT);
        db.execSQL(CREATE_TABLE_SECTION);
        db.execSQL(CREATE_TABLE_COURSE);
        db.execSQL(CREATE_TABLE_SECTIONSUBJECT);
        db.execSQL(CREATE_TABLE_SECTIONSTUDENT);
        db.execSQL(CREATE_TABLE_SUBJECTSTUDENT);
        db.execSQL(CREATE_TABLE_ATTENDANCE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldversion, int newversion)
    {
        String DROPIFEXIST_TABLESTUDENT = "DROP TABLE IF EXISTS "+TABLE_STUDENT;
        String DROPIFEXIST_TABLESUBJECT = "DROP TABLE IF EXISTS "+TABLE_SUBJECT;
        String DROPIFEXIST_TABLESECTION = "DROP TABLE IF EXISTS "+TABLE_SECTION;
        String DROPIFEXIST_TABLECOURSE = "DROP TABLE IF EXISTS "+TABLE_COURSE;
        String DROPIFEXIST_TABLESECTIONSUBJECT = "DROP TABLE IF EXISTS "+TABLE_SECTIONSUBJECT;
        String DROPIFEXIST_TABLESECTIONSTUDENT = "DROP TABLE IF EXISTS "+TABLE_SECTIONSTUDENT;
        String DROPIFEXIST_TABLESUBJECTSTUDENT = "DROP TABLE IF EXISTS "+TABLE_SUBJECTSTUDENT;
        String DROPIFEXIST_TABLEATTENDANCE = "DROP TABLE IF EXISTS "+TABLE_ATTENDANCE;

        db.execSQL(DROPIFEXIST_TABLESTUDENT);
        db.execSQL(DROPIFEXIST_TABLESUBJECT);
        db.execSQL(DROPIFEXIST_TABLESECTION);
        db.execSQL(DROPIFEXIST_TABLECOURSE);
        db.execSQL(DROPIFEXIST_TABLESECTIONSUBJECT);
        db.execSQL(DROPIFEXIST_TABLESECTIONSTUDENT);
        db.execSQL(DROPIFEXIST_TABLESUBJECTSTUDENT);
        db.execSQL(DROPIFEXIST_TABLEATTENDANCE);

        onCreate(db);
    }

    public boolean isexist_studentnumber(String SN)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        int count = db.rawQuery("SELECT "+STUDENT_NUMBER+" from "+TABLE_STUDENT+" where "+STUDENT_NUMBER+" = '"+SN+"'",null).getCount();

        if(count > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void addStudent(Students stud)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();

        val.put(STUDENT_NUMBER, stud.getStudent_number());
        val.put(COURSE, stud.getCourse());
        val.put(FNAME, stud.getFirstname());
        val.put(MNAME, stud.getMiddlename());
        val.put(LNAME, stud.getLastname());
        val.put(EXT, stud.getExt());

        db.insert(TABLE_STUDENT, null, val);
        db.close();
    }

    public void addSectionSubject(SectionSubject secsubj)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();

        val.put(SECTIONSUBJECT_COURSEID, secsubj.getCourse_id());
        val.put(SECTIONSUBJECT_SECTIONID, secsubj.getSection_id());
        val.put(SECTIONSUBJECT_SUBJECTID, secsubj.getSubject_id());
        val.put(SECTIONSUBJECT_SCHEDULEDAYS, secsubj.getScheduledays());

        db.insert(TABLE_SECTIONSUBJECT, null, val);
        db.close();
    }

    public void addSubject(Subjects subj)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();

        val.put(SUBJECT_CODE, subj.getSubject_code());
        val.put(SUBJECT_DESCRIPTION, subj.getSubject_description());
        val.put(SUBJECT_NOUNITS, subj.getSubject_nounits());

        db.insert(TABLE_SUBJECT, null, val);
        db.close();
    }

    public void Add_Section(Sections sec)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();

        v.put(SECTION_NAME,sec.getSection_name());
        v.put(SECTION_COURSE,sec.getSection_course());

        db.insert(TABLE_SECTION, null,v);
        db.close();
    }

    public void Add_Course(Course cc)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();

        val.put(COURSE_DESC, cc.getCourse_desc());
        val.put(COURSE_ABBREV, cc.getCourse_abbrev());
        val.put(COURSE_MAXYEAR, cc.getMaxyear());

        db.insert(TABLE_COURSE, null,val);
        db.close();
    }

   public void addSectionStudent(SectionStudent secstud)
   {
        SQLiteDatabase db = this.getWritableDatabase();
       ContentValues cv = new ContentValues();

       cv.put(SECTIONSTUDENT_STUDENTID, secstud.getStudent_id());
       cv.put(SECTIONSTUDENT_SECTIONID, secstud.getSection_id());

       db.insert(TABLE_SECTIONSTUDENT, null, cv);
       db.close();
   }

    public void addSubjectStudent(SubjectStudent substud)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();

        v.put(SUBJECTSTUDENT_SUBJECTID, substud.getSubject_id());
        v.put(SUBJECTSTUDENT_STUDENTID, substud.getStudent_id());

        db.insert(TABLE_SUBJECTSTUDENT, null, v);
        db.close();
    }

    public void updateStudent(Students stud, int student_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(STUDENT_NUMBER,stud.getStudent_number());
        cv.put(FNAME,stud.getFirstname());
        cv.put(LNAME,stud.getLastname());
        cv.put(MNAME,stud.getMiddlename());
        cv.put(EXT,stud.getExt());

        db.update(TABLE_STUDENT, cv, KEY_ID + " = ?", new String[]{String.valueOf(student_id)});
        db.close();
    }

    public List<SectionSubject> getAllSectionSubject()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_SECTIONSUBJECT + "", null);

        List<SectionSubject> sec = new ArrayList<>();

        if(c.moveToFirst())
        {
            do {
                SectionSubject s = new SectionSubject();

                s.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                s.setSection_id(Integer.parseInt(c.getString(c.getColumnIndex(SECTIONSUBJECT_SECTIONID))));
                s.setSubject_id(Integer.parseInt(c.getString(c.getColumnIndex(SECTIONSUBJECT_SUBJECTID))));

                sec.add(s);
            }while(c.moveToNext());
        }

        return sec;
    }



    public List<Sections> getAllSections()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_SECTION + "", null);

        List<Sections> sec = new ArrayList<>();

        if(c.moveToFirst())
        {
            do {
                Sections s = new Sections();

                s.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                s.setSection_name(c.getString(c.getColumnIndex(SECTION_NAME)));
                s.setSection_course(Integer.parseInt(c.getString(c.getColumnIndex(SECTION_COURSE))));

                sec.add(s);
            }while(c.moveToNext());
        }

        return sec;
    }

    public List<SectionStudent> getAllSectionStudents()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_SECTIONSTUDENT + "", null);

        List<SectionStudent> sec = new ArrayList<>();

        if(c.moveToFirst())
        {
            do {
                SectionStudent s = new SectionStudent();

                s.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                s.setSection_id(Integer.parseInt(c.getString(c.getColumnIndex(SECTIONSTUDENT_SECTIONID))));
                s.setStudent_id(Integer.parseInt(c.getString(c.getColumnIndex(SECTIONSTUDENT_STUDENTID))));

                sec.add(s);
            }while(c.moveToNext());
        }

        return sec;
    }

    public List<Course> getAllCourses()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM "+TABLE_COURSE;

        Cursor c = db.rawQuery(sql, null);

        List<Course> cours = new ArrayList<>();

        if(c.moveToFirst())
        {
            do
            {
                Course curs = new Course();

                curs.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                curs.setCourse_abbrev(c.getString(c.getColumnIndex(COURSE_ABBREV)));
                curs.setCourse_desc(c.getString(c.getColumnIndex(COURSE_DESC)));

                cours.add(curs);
            }
            while(c.moveToNext());

        }

        return cours;
    }


    public List<Course> getCourse(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_COURSE + " where ID = " + id + "", null);

        List<Course> cour = new ArrayList<>();

        if(c.moveToFirst())
        {
            do {

                Course cc = new Course();

                cc.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                cc.setCourse_desc(c.getString(c.getColumnIndex(COURSE_DESC)));
                cc.setCourse_abbrev(c.getString(c.getColumnIndex(COURSE_ABBREV)));

                cour.add(cc);

            }while(c.moveToNext());
        }

        return cour;
    }

    public List<Sections> getSection(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_SECTION + " where " + KEY_ID + " = " + id + "", null);

        List<Sections> sec = new ArrayList<>();

        if(c.moveToFirst())
        {
            do
            {
                Sections cc = new Sections();
                cc.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                cc.setSection_name(c.getString(c.getColumnIndex(SECTION_NAME)));
                sec.add(cc);
            }
            while(c.moveToNext());
        }

        return sec;
    }

    public List<Students> getStudent(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM "+TABLE_STUDENT+ " WHERE ID = "+ id+"";

        Cursor c = db.rawQuery(sql,null);

        List<Students> s = new ArrayList<Students>();

        if(c.moveToFirst())
        {
            do
            {
                Students stud = new Students();

                stud.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                stud.setCourse(Integer.parseInt(c.getString(c.getColumnIndex(COURSE))));
                stud.setFirstname(c.getString(c.getColumnIndex(FNAME)));
                stud.setMiddlename(c.getString(c.getColumnIndex(MNAME)));
                stud.setLastname(c.getString(c.getColumnIndex(LNAME)));
                stud.setExt(c.getString(c.getColumnIndex(EXT)));
                stud.setStudent_number(c.getString(c.getColumnIndex(STUDENT_NUMBER)));

                s.add(stud);
            }while(c.moveToNext());
        }

        return s;

    }

    public List<Students> getStudentBySN(String SN)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM "+TABLE_STUDENT+ " WHERE "+STUDENT_NUMBER+" = '"+ SN +"'";

        Cursor c = db.rawQuery(sql,null);

        List<Students> s = new ArrayList<Students>();

        if(c.moveToFirst())
        {
            do
            {
                Students stud = new Students();

                stud.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                stud.setCourse(Integer.parseInt(c.getString(c.getColumnIndex(COURSE))));
                stud.setFirstname(c.getString(c.getColumnIndex(FNAME)));
                stud.setMiddlename(c.getString(c.getColumnIndex(MNAME)));
                stud.setLastname(c.getString(c.getColumnIndex(LNAME)));
                stud.setExt(c.getString(c.getColumnIndex(EXT)));
                stud.setStudent_number(c.getString(c.getColumnIndex(STUDENT_NUMBER)));

                s.add(stud);
            }while(c.moveToNext());
        }

        return s;

    }

    public List<Subjects> getSubject(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * from " + TABLE_SUBJECT + " where ID = " + id + "", null);

        List<Subjects> subs = new ArrayList<>();

        if(c.moveToFirst())
        {
            do {

                Subjects ss = new Subjects();

                ss.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                ss.setSubject_code(c.getString(c.getColumnIndex(SUBJECT_CODE)));
                ss.setSubject_description(c.getString(c.getColumnIndex(SUBJECT_DESCRIPTION)));
                ss.setSubject_nounits(Integer.parseInt(c.getString(c.getColumnIndex(SUBJECT_NOUNITS))));

                subs.add(ss);

            }while(c.moveToNext());
        }

        return subs;
    }

    public List<Subjects> getAllSubjects()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM "+TABLE_SUBJECT;

        Cursor c = db.rawQuery(sql, null);

        List<Subjects> s = new ArrayList<Subjects>();


            if(c.moveToFirst())
            {
                do
                {
                    Subjects subj = new Subjects();

                    subj.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                    subj.setSubject_code(c.getString(c.getColumnIndex(SUBJECT_CODE)));
                    subj.setSubject_description(c.getString(c.getColumnIndex(SUBJECT_DESCRIPTION)));
                    subj.setSubject_nounits(Integer.parseInt(c.getString(c.getColumnIndex(SUBJECT_NOUNITS))));

                    s.add(subj);
                }
                while(c.moveToNext());

            }


        return s;
    }

    public List<Students> getAllStudents()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM "+TABLE_STUDENT;

        Cursor c = db.rawQuery(sql,null);

        List<Students> s = new ArrayList<Students>();

        if(c.moveToFirst())
        {
            do
            {
                Students stud = new Students();

                stud.setID(Integer.parseInt(c.getString(c.getColumnIndex(KEY_ID))));
                stud.setCourse(Integer.parseInt(c.getString(c.getColumnIndex(COURSE))));
                stud.setFirstname(c.getString(c.getColumnIndex(FNAME)));
                stud.setMiddlename(c.getString(c.getColumnIndex(MNAME)));
                stud.setLastname(c.getString(c.getColumnIndex(LNAME)));
                stud.setExt(c.getString(c.getColumnIndex(EXT)));
                stud.setStudent_number(c.getString(c.getColumnIndex(STUDENT_NUMBER)));

                s.add(stud);
            }while(c.moveToNext());
        }

        return s;

    }

    public void deleteStudent(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_STUDENT, KEY_ID + " = ?", new String[] {String.valueOf(id)});
        db.delete(TABLE_SECTIONSTUDENT, SECTIONSTUDENT_STUDENTID+" = ?", new String[] {String.valueOf(id)});
        db.close();
    }

    public void deleteSection(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SECTION, KEY_ID + " = ?", new String[] {String.valueOf(id)});
        db.close();
    }

    public void deleteSectionSubjects(String section_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SECTIONSUBJECT, SECTIONSUBJECT_SECTIONID + " = ?", new String[] {String.valueOf(section_id)});
        db.close();
    }

    public void deleteSectionStudent(String section_id, String student_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SECTIONSTUDENT, SECTIONSTUDENT_SECTIONID + " = ? and "+SECTIONSTUDENT_STUDENTID+" = ?", new String[] {String.valueOf(section_id),String.valueOf(student_id)});
        db.close();
    }

    public void deleteAssignedSubject(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SECTIONSUBJECT, SECTIONSUBJECT_SUBJECTID + " = ?", new String[] {String.valueOf(id)});
        db.close();
    }

}
