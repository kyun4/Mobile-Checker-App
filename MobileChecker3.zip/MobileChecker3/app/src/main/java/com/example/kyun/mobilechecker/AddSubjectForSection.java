package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import org.apache.poi.hpsf.Section;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class AddSubjectForSection extends AppCompatActivity {

    Spinner subjectspinner;
    Button btnBack;
    Button btnAddSubject;
    ListView lst;

    SubjectAdapter subjectAdapter = null;

    public static int section_id = 0;
    public static int course_id = 0;
    public static int subject_id = 0;

    ArrayList<Subjects> lstSubjs = new ArrayList<>();

    // for spinner
    List<Subjects> lstSubjects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subject_for_section);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        subjectspinner = (Spinner) findViewById(R.id.subjectspinner);
        btnBack = (Button) findViewById(R.id.btnBack);

        lst = (ListView)findViewById(R.id.list_subject_assigned);

        Intent intent = getIntent();

        section_id = intent.getIntExtra("section_id",0);
        course_id = intent.getIntExtra("course_id",0);


        final List<String> lstSubject = new ArrayList<String>();

        DBHandler db = new DBHandler(this);

        List<Sections> lsec = db.getSection(section_id);

        List<Course> lcur = db.getCourse(course_id);
        toolbar.setSubtitle(lcur.get(0).getCourse_abbrev() + " " + lsec.get(0).getSection_name());

        lstSubjects = db.getAllSubjects();

        lstSubject.clear();

        for(Subjects subj:lstSubjects)
        {
            lstSubject.add(subj.getSubject_description() + " ("+subj.getSubject_code()+")");
        }

        ArrayAdapter<String> subject_item = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lstSubject);
        subject_item.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectspinner.setAdapter(subject_item);

         lstSubjs.clear();
          List<SectionSubject> lstsecsub = db.getAllSectionSubject();

        List<Subjects> subject_info = db.getAllSubjects();

         for(SectionSubject secsub:lstsecsub)
         {
             if(section_id == secsub.getSection_id())
             {

                 String subjectdesc = "";
                 String subjectcode = "";
                 int units = 2;

                 for(Subjects sub:subject_info)
                 {
                     if(secsub.getSubject_id() == sub.getID())
                     {
                         subjectdesc = sub.getSubject_description();
                         subjectcode  = sub.getSubject_code();
                         units = sub.getSubject_nounits();
                     }
                 }

                 lstSubjs.add(new Subjects(secsub.getSubject_id(), "" +  subjectdesc+ "", ""+subjectcode+"", units));

             }

         }

        subjectAdapter = new SubjectAdapter(getApplicationContext(), R.layout.item_subjects, lstSubjs);

        AdapterView.OnItemLongClickListener assignedsubjectlongclick = new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l){

                final int pos = i;
                final CharSequence[] items = {"Delete","Cancel"};

                new AlertDialog.Builder(AddSubjectForSection.this).setTitle("Assigned Subject List").setItems(items, new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int item)
                    {
                        if(item == 0)
                        {

                            Subjects sub = lstSubjs.get(pos);

                            DBHandler dbs = new DBHandler(AddSubjectForSection.this);

                            subjectAdapter.remove(subjectAdapter.getItem(pos));
                            subjectAdapter.notifyDataSetChanged();

                            dbs.deleteAssignedSubject("" + sub.getID() + "");

                            notificationAlert("Assigning of Subjects in your Class","1 Assigned Subject Deleted", "OK");

                        }
                        else if(item == 1)
                        {
                            dialog.dismiss();
                        }
                    }

                }).show();

                return false;
            }
        };

        lst.setAdapter(subjectAdapter);
        lst.setOnItemLongClickListener(assignedsubjectlongclick);

        AdapterView.OnClickListener btnClickBack = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddSubjectForSection.this, MainActivity.class);
                startActivity(intent);
            }
        };


        btnBack.setOnClickListener(btnClickBack);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHandler db = new DBHandler(getApplicationContext());

                List<Subjects> lstsub = db.getAllSubjects();

                subject_id = lstsub.get(subjectspinner.getSelectedItemPosition()).getID();

                db.addSectionSubject(new SectionSubject(1, "Monday, Wednesday",section_id,subject_id,course_id));

                lstSubjs.clear();

                List<SectionSubject> lstsecsub = db.getAllSectionSubject();

                List<Subjects> subject_info = db.getAllSubjects();

                for(SectionSubject secsub:lstsecsub)
                {
                    if(section_id == secsub.getSection_id())
                    {

                        String subjectdesc = "";
                        String subjectcode = "";
                        int units = 2;

                        for(Subjects sub:subject_info)
                        {
                            if(secsub.getSubject_id() == sub.getID())
                            {
                                subjectdesc = sub.getSubject_description();
                                subjectcode  = sub.getSubject_code();
                                units = sub.getSubject_nounits();
                            }
                        }

                        lstSubjs.add(new Subjects(secsub.getID(), "" +  subjectdesc+ "", ""+subjectcode+"", units));

                    }

                }

                subjectAdapter.notifyDataSetChanged();
            }
        });
    }

    public void notificationAlert(String title, String msg, String bottomAlert)
    {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

}
