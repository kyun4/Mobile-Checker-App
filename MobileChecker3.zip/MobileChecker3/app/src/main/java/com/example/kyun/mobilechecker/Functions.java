package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 10/1/2017.
 */
public class Functions {

    public Functions()
    {

    }


    public ArrayList<Sections> loadSections(Context ctx)
    {

        DBHandler db = new DBHandler(ctx);

        List<Sections> secs = db.getAllSections();

        ArrayList<Sections> lstsection = new ArrayList<>();

        for(Sections s:secs)
        {
            lstsection.add(new Sections(s.getID(),""+s.getSection_name().toString()+"",s.getSection_course()));
        }

        return lstsection;
    }

    public List<Students> getStudentInfoByID(Context ctx, int student_id)
    {
        DBHandler db = new DBHandler(ctx);

        List<Students> studs = new ArrayList<>();
        studs = db.getStudent(student_id);

        return studs;
    }


    public void spinnerAdapter(Spinner spinner,List<String> lst, Context ctx)
    {
        ArrayAdapter<String> spin_adapter = new ArrayAdapter<String>(ctx, android.R.layout.simple_spinner_item, lst);
        spin_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spin_adapter);
    }

    public void removeitem_adapter(ArrayAdapter adapterView, int pos)
    {
        adapterView.remove(adapterView.getItem(pos));
        adapterView.notifyDataSetChanged();
    }

    public void deleteSection_SectionSubject(int secid, Context ctx)
    {
        DBHandler db = new DBHandler(ctx);
        db.deleteSection("" + secid + "");
        db.deleteSectionSubjects("" + secid + "");
    }

    public List<String> loadCourseSpinner(Context ctx,String deftext)
    {
        List<String> lstcourse = new ArrayList<>();

        DBHandler db = new DBHandler(ctx);

        lstcourse.add(""+deftext+"");

        int cint = 1;

        for(Course c:db.getAllCourses())
        {
            List<Course> courselist = db.getCourse(cint);
            lstcourse.add(courselist.get(0).getCourse_desc());
            cint++;
        }

        return lstcourse;
    }

    public void loadDegreeSpinner(Spinner degreespinner,Context ctx)
    {
        List<String> degree_list = new ArrayList<String>();

        degree_list.add("-- Degree --");
        degree_list.add("Master of Arts in");
        degree_list.add("Bachelor of Science in");
        degree_list.add("Associate of Science in");
        degree_list.add("Associate of Arts in");

        ArrayAdapter<String> degreeAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item,degree_list);

        degreeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        degreespinner.setAdapter(degreeAdapter);
    }

    public void loadMaxYearSpinner(Spinner maxyearspinner, Context ctx)
    {
        List<String> yearSpinner = new ArrayList<String>();
        yearSpinner.add("-- Max Year --");

        for(int i = 1;i<=5;i++)
        {
            yearSpinner.add(""+i+"");
        }

        ArrayAdapter<String>  yearAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item,yearSpinner);

        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        maxyearspinner.setAdapter(yearAdapter);
    }

    public void addSection(String section_name,int course_id, Context ctx)
    {
        DBHandler db = new DBHandler(ctx);
        db.Add_Section(new Sections(1, "" + section_name + "", course_id));
    }

    public void addCourse(Spinner degreespinner, EditText txtCourseDesc, Spinner maxyearspinner, EditText txtCourseAbbrev, Context context)
    {
        String courseDesc = degreespinner.getSelectedItem().toString()+" "+txtCourseDesc.getText().toString();
        DBHandler db = new DBHandler(context);

        db.Add_Course(new Course(1, courseDesc, txtCourseAbbrev.getText().toString(), Integer.parseInt(maxyearspinner.getSelectedItem().toString())));

    }

    public int getCourseIDfromSpinner(Spinner coursespinner,Context ctx)
    {
        DBHandler dbc = new DBHandler(ctx);
        List<Course> crs = dbc.getCourse(coursespinner.getSelectedItemPosition());

        return crs.get(0).getID();
    }

    public void notificationAlert(String title, String msg, String bottomAlert, Context context)
    {

        new AlertDialog.Builder(context).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

    public void msgshort(Context ctx, String msg)
    {
        Toast.makeText(ctx, "" + msg + "", Toast.LENGTH_SHORT).show();
    }

    public void msglong(Context ctx, String msg)
    {
        Toast.makeText(ctx,""+msg+"", Toast.LENGTH_LONG).show();
    }

    public String getSectionNameById(Context ctx,int secid)
    {
        DBHandler db = new DBHandler(ctx);

        List<Sections> lsec = new ArrayList<>();
        lsec = db.getSection(secid);

        return lsec.get(0).getSection_name().toString();
    }

    public List<Students> getStudentInfoBySN(Context ctx,String SN)
    {
        DBHandler db = new DBHandler(ctx);

        List<Students> lst_stud = new ArrayList<>();
        lst_stud = db.getStudentBySN(SN);

        return lst_stud;
    }

    public String getCourseAbbrevById(Context ctx,int courseid)
    {
        DBHandler db = new DBHandler(ctx);

        List<Course> lsec = new ArrayList<>();
        lsec = db.getCourse(courseid);

        return lsec.get(0).getCourse_abbrev().toString();
    }

    public int testifexist_name(Context ctx, EditText FN, EditText MN, EditText LN, EditText EXT)
    {
        DBHandler db = new DBHandler(ctx);
        List<Students> stud = new ArrayList<>();
        stud = db.getAllStudents();

        int i = 0;

        for(Students s:stud)
        {
            if(FN.getText().toString().trim().equals(""+s.getFirstname()+"") && MN.getText().toString().trim().equals(""+s.getFirstname()+"") && LN.getText().toString().trim().equals(""+s.getFirstname()+"") && EXT.getText().toString().trim().equals(""+s.getExt()+""))
            {
                i = 1;
            }
        }

        return i;
    }

    public void snackbar(View view, String msg)
    {
        Snackbar.make(view, msg, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    public void dialog_positive_goto_student(String positivetext, String title, Context ctx)
    {
        new AlertDialog.Builder(ctx).setTitle(title).setPositiveButton("" + positivetext + "", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

            }

        }).show();
    }

    public void updateStudents(Students stud, int student_id, Context ctx)
    {
        DBHandler db = new DBHandler(ctx);
        db.updateStudent(stud, student_id);
    }

}
