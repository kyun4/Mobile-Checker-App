package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;
import java.util.List;

public class EditStudent extends AppCompatActivity {

    Button btnBack;
    Functions func = new Functions();
    public static int student_id;

    public static List<Students> lststud = new ArrayList<>();

    EditText txtSN, txtFN, txtMN, txtLN, txtEXT;
    Spinner coursepinner, maxyearspinner;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        student_id = intent.getIntExtra("student_id", 0);

        txtSN = (EditText) findViewById(R.id.txtStudentNumber);
        txtFN = (EditText) findViewById(R.id.txtFirstName);
        txtMN = (EditText) findViewById(R.id.txtMiddleName);
        txtLN = (EditText) findViewById(R.id.txtLastName);
        txtEXT = (EditText) findViewById(R.id.txtEXT);

        coursepinner = (Spinner) findViewById(R.id.coursepinner);
        maxyearspinner = (Spinner) findViewById(R.id.maxyearspinner);

        btnBack = (Button) findViewById(R.id.btnBack);


        lststud = func.getStudentInfoByID(this,student_id);

        txtSN.setText(""+lststud.get(0).getStudent_number()+"");
        txtFN.setText(""+lststud.get(0).getFirstname()+"");
        txtMN.setText(""+lststud.get(0).getMiddlename()+"");
        txtLN.setText(""+lststud.get(0).getLastname()+"");
        txtEXT.setText(""+lststud.get(0).getExt()+"");

        int courseid = lststud.get(0).getCourse();



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EditStudent.this, StudentsList.class);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Students newStud = new Students();

                newStud.setStudent_number(txtSN.getText().toString());
                newStud.setFirstname(txtFN.getText().toString());
                newStud.setMiddlename(txtMN.getText().toString());
                newStud.setLastname(txtLN.getText().toString());
                newStud.setExt(txtEXT.getText().toString());

                func.updateStudents(newStud,student_id,EditStudent.this);

                new AlertDialog.Builder(EditStudent.this).setTitle("Student Information Successfully Changed!").setPositiveButton("Done", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {



                        Intent intent = new Intent(EditStudent.this, StudentsList.class);
                        startActivity(intent);
                    }

                }).show();


            }
        });
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "EditStudent Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.kyun.mobilechecker/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "EditStudent Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.kyun.mobilechecker/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}
