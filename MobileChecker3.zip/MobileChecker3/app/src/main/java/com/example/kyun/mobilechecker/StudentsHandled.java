package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/19/2017.
 */
public class StudentsHandled {

    private String fname;
    private String mname;
    private String lname;
    private String ext;
    private String year;
    private String section;
    private String course;
    private int studentImage;
    private String student_type;
    private String student_number;

    private int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public StudentsHandled()
    {

    }


    public StudentsHandled(int ID, String fname, String mname, String lname, String ext, String year, String section, String course, int studentImage, String student_number, String student_type)
    {
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
        this.ext = ext;
        this.year = year;
        this.section = section;
        this.course = course;
        this.studentImage = studentImage;
        this.student_number = student_number;
        this.student_type = student_type;
        this.ID = ID;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getStudentImage() {
        return studentImage;
    }

    public void setStudentImage(int studentImage) {
        this.studentImage = studentImage;
    }

    public String getStudent_type() {
        return student_type;
    }

    public void setStudent_type(String student_type) {
        this.student_type = student_type;
    }

    public String getStudent_number() {
        return student_number;
    }

    public void setStudent_number(String student_number) {
        this.student_number = student_number;
    }
}
