package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/29/2017.
 */
public class SectionSubject {

    private String scheduledays;
    private int section_id;
    private int course_id;
    private int subject_id;
    private int ID;

    public SectionSubject()
    {

    }

    public SectionSubject(int ID, String scheduledays, int section_id, int subject_id, int course_id)
    {
        this.ID = ID;
        this.scheduledays = scheduledays;
        this.section_id = section_id;
        this.subject_id = subject_id;
        this.course_id = course_id;
    }

    public String getScheduledays() {
        return scheduledays;
    }

    public void setScheduledays(String scheduledays) {
        this.scheduledays = scheduledays;
    }

    public int getSection_id() {
        return section_id;
    }

    public void setSection_id(int section_id) {
        this.section_id = section_id;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    public int getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(int subject_id) {
        this.subject_id = subject_id;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
