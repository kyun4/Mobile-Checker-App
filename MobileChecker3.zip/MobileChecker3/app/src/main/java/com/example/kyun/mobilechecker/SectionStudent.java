package com.example.kyun.mobilechecker;

/**
 * Created by kyun on 9/29/2017.
 */
public class SectionStudent {

    private int ID;
    private int student_id;
    private int section_id;

    public SectionStudent(int ID, int student_id, int section_id)
    {

        this.ID = ID;
        this.student_id = student_id;
        this.section_id = section_id;

    }

    public SectionStudent()
    {


    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public int getSection_id() {
        return section_id;
    }

    public void setSection_id(int section_id) {
        this.section_id = section_id;
    }
}
