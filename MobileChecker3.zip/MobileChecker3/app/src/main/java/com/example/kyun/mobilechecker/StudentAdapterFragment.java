package com.example.kyun.mobilechecker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 9/19/2017.
 */
public class StudentAdapterFragment extends ArrayAdapter<Students> {

    Context context;
    List<Students> lstStudents;

    public StudentAdapterFragment(Context context, int resourceid, ArrayList<Students> objects)
    {

        super(context, resourceid, objects);
        this.context = context;
        this.lstStudents = objects;

    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = convertView;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.list_item_student, null);

        Students sList = lstStudents.get(position);

        TextView txtFullname = (TextView) v.findViewById(R.id.txtfullname);
        TextView txtStudentNumber = (TextView) v.findViewById(R.id.txtstudentnumber);
        TextView txtInfo = (TextView) v.findViewById(R.id.txtcourse);


        String fullname = String.valueOf(sList.getLastname().toString().toUpperCase()+", "+sList.getFirstname().toString()+" "+sList.getMiddlename().toString()+" "+sList.getExt().toString()+"");

        txtFullname.setText(fullname);
        txtStudentNumber.setText(sList.getStudent_number().toString());
       // txtInfo.setText(sList.getCourse().toString()+" "+sList.getSection().toString()+" "+sList.getYear().toString());


        return v;
    }

}
