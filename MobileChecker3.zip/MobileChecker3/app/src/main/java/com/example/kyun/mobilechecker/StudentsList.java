package com.example.kyun.mobilechecker;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.time.format.TextStyle;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class StudentsList extends AppCompatActivity {


   public static File file = null;
   public static String subjectcode = "";
    public static String subjectname = "";
    StudentAdapter studAdapter;

    public static ArrayList<Students> lstStudents = new ArrayList<Students>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        subjectcode = intent.getStringExtra("subjectcode");
        subjectname = intent.getStringExtra("subjectname");


        if(subjectcode == null || subjectcode.equals("") || subjectname == null || subjectname.equals(""))
        {

        }
        else
        {
            toolbar.setSubtitle(subjectcode + " " + subjectname);
        }


        DBHandler db = new DBHandler(this);
        loadStudents(db);

        ListView lstviewStudents = (ListView) findViewById(R.id.list_students);
        studAdapter = new StudentAdapter(this, R.layout.list_item_student, lstStudents);

        AdapterView.OnItemLongClickListener longclickstudent = new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> adapterView, View view, int i, long l) {

                final int pos = i;
               final Students stud = lstStudents.get(i);
                //final CharSequence[] items = {"Add to Section","Add to Subject Only","Delete","Cancel"};
                final CharSequence[] items = {"Edit","Delete","Cancel"};

                new AlertDialog.Builder(StudentsList.this).setTitle("Student List").setItems(items, new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int item)
                    {
                        if(item == 0)
                        {

                           Intent intent = new Intent(StudentsList.this, EditStudent.class);

                            intent.putExtra("student_id", stud.getID());

                            startActivity(intent);

                        }
                        else if(item == 1)
                        {



                            DBHandler db = new DBHandler(StudentsList.this);
                            db.deleteStudent("" + stud.getID() + "");

                            studAdapter.remove(studAdapter.getItem(pos));
                            studAdapter.notifyDataSetChanged();

                            loadStudents(db);

                            notificationAlert("Student List", "1 Student Deleted", "OK");

                        }
                        else if(item == 2)
                        {
                           // Intent intent = new Intent(getApplicationContext(), AddtoSubject.class);
                           // startActivity(intent);
                            dialog.dismiss();
                        }
                        else
                        {
                            dialog.dismiss();
                        }
                    }

                }).show();

                return false;
            }
        };

        lstviewStudents.setAdapter(studAdapter);
        lstviewStudents.setOnItemLongClickListener(longclickstudent);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(StudentsList.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void loadStudents(DBHandler db)
    {

        List<Students> lst = db.getAllStudents();

        lstStudents.clear();

        for(Students stud:lst)
        {
            lstStudents.add(new Students(stud.getID(), stud.getStudent_number(), stud.getCourse(), stud.getFirstname(), stud.getMiddlename(),stud.getLastname(), stud.getExt()));
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mainstudents, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        else   if (id == R.id.action_excelgen) {

            // Toast.makeText(StudentsList.this, "Generating Excel File ... ", Toast.LENGTH_SHORT).show();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void notificationAlert(String title, String msg, String bottomAlert)
    {

        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

}
