package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AddSection extends AppCompatActivity {


    public static String section = "";
    public static int course = 0;

    EditText txtSectionName = null;
    Spinner coursespinner = null;

    List<String> lstcourse = new ArrayList<>();

    Functions func = new Functions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_section);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtSectionName = (EditText) findViewById(R.id.txtSectionName);
        coursespinner = (Spinner) findViewById(R.id.courseSpinner);

        Button btn = (Button) findViewById(R.id.btnBack);

        lstcourse = func.loadCourseSpinner(this,"-- Course --");

        func.spinnerAdapter(coursespinner, lstcourse, this);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddSection.this, MainActivity.class);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(txtSectionName.getText().toString().trim().equals(""))
                {
                    func.msgshort(AddSection.this, "Section Name is Empty");
                }
                if(coursespinner.getSelectedItem().toString().trim().equals("-- Course --"))
                {
                   func.msgshort(AddSection.this, "Please specify section's course/program ");
                }
                else
                {
                    section = txtSectionName.getText().toString().trim();

                    course = func.getCourseIDfromSpinner(coursespinner,AddSection.this);

                    func.addSection(section, course, AddSection.this);

                    func.notificationAlert("" + section + "", "1 Section Added " + coursespinner.getSelectedItemPosition() + "", "OK",AddSection.this);

                    txtSectionName.setText("");
                    coursespinner.setSelection(0);
                }


            }
        });
    }




}
