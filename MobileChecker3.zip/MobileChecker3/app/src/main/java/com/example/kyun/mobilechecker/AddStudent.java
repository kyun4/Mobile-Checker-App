package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AddStudent extends AppCompatActivity {

    public static String fullname = "";
    EditText txtFN = null;
    EditText txtMN = null;
    EditText txtLN = null;
    EditText txtEXT = null;
    EditText txtSN = null;
    Spinner coursespinner;
    Spinner yearspinner = null;

    Functions func = new Functions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button btn = (Button) findViewById(R.id.btnBack);

        txtFN = (EditText) findViewById(R.id.txtFirstName);
       txtMN = (EditText) findViewById(R.id.txtMiddleName);
       txtLN = (EditText) findViewById(R.id.txtLastName);
       txtEXT = (EditText) findViewById(R.id.txtExt);
       txtSN = (EditText) findViewById(R.id.txtSN);
        coursespinner = (Spinner) findViewById(R.id.courseSpinner);

        yearspinner = (Spinner) findViewById(R.id.yearspinner);

        DBHandler db = new DBHandler(this);

        List<String> lstcourse = new ArrayList<String>();

        lstcourse = func.loadCourseSpinner(this, "-- Course --");

       final List<String> lstyear = new ArrayList<String>();

        lstyear.add("-- Year Level --");
        lstyear.add("1st Year");
        lstyear.add("2nd Year");
        lstyear.add("3rd Year");
        lstyear.add("4th Year");

        AdapterView.OnItemSelectedListener selectcourse = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                lstyear.clear();
                lstyear.add("-- Year Level --");

                int maxyear = 4;

                for(int ii = 1;ii<=maxyear;ii++)
                {
                    lstyear.add(""+convertToStr(ii)+" Year");
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };


        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, lstyear);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        yearspinner.setAdapter(yearAdapter);
        yearspinner.setOnItemSelectedListener(selectcourse);

        func.spinnerAdapter(coursespinner, lstcourse, this);
        coursespinner.setOnItemSelectedListener(selectcourse);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddStudent.this, MainActivity.class);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {

                if(txtFN.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddStudent.this, "First Name is Empty" ,Toast.LENGTH_SHORT).show();
                }
                else if(txtLN.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddStudent.this, "Last Name is Empty" ,Toast.LENGTH_SHORT).show();
                }
                else if(txtSN.getText().toString().trim().equals(""))
                {
                    Toast.makeText(AddStudent.this, "Student Number is Empty" ,Toast.LENGTH_SHORT).show();
                }
                else if(coursespinner.getSelectedItem().toString().trim().equals("-- Course --"))
                {
                    Toast.makeText(AddStudent.this, "Course is not specified" ,Toast.LENGTH_SHORT).show();
                }
                else if(yearspinner.getSelectedItem().toString().trim().equals("-- Year Level --"))
                {
                    Toast.makeText(AddStudent.this, "Year Level is not specified" ,Toast.LENGTH_SHORT).show();
                }
                else if(yearspinner.getSelectedItem().toString().trim().equals(""))
                {
                    Toast.makeText(AddStudent.this, "Year Level is not specified" ,Toast.LENGTH_SHORT).show();
                }
                else
                {

                    DBHandler db = new DBHandler(AddStudent.this);

                    if(db.isexist_studentnumber(txtSN.getText().toString().trim()) == false)
                    {
                        fullname = txtFN.getText().toString()+" "+txtMN.getText().toString()+" "+txtLN.getText().toString()+" "+txtEXT.getText().toString();
                        notificationAlert("" + fullname + "", "1 Student Saved", "OK");

                        db.addStudent(new Students(1,""+txtSN.getText().toString()+"",coursespinner.getSelectedItemPosition(), ""+txtFN.getText().toString()+"",""+txtMN.getText().toString()+"",""+txtLN.getText().toString()+"",""+txtEXT.getText().toString()+""));

                        txtSN.setText("");
                        txtFN.setText("");
                        txtMN.setText("");
                        txtLN.setText("");
                        txtEXT.setText("");

                        coursespinner.setSelection(0);
                        yearspinner.setSelection(0);
                    }
                    else if(func.testifexist_name(AddStudent.this,txtFN,txtMN, txtLN, txtEXT) == 1)
                    {
                        notificationAlert("Add Student","Record already exists, Please check your student list", "OK");
                    }
                    else
                    {

                        String SN  = txtSN.getText().toString();
                        String fname = func.getStudentInfoBySN(AddStudent.this,""+SN+"").get(0).getFirstname();
                        String mname = func.getStudentInfoBySN(AddStudent.this,""+SN+"").get(0).getMiddlename();
                        String lname = func.getStudentInfoBySN(AddStudent.this,""+SN+"").get(0).getLastname();
                        String ext = func.getStudentInfoBySN(AddStudent.this,""+SN+"").get(0).getExt();

                        notificationAlert("Existing Record for Student Number "+SN+"",""+fname+" "+mname+" "+lname+" "+ext+" ", "OK");
                        notificationAlert("Add Student","Student Number Already Exists", "OK");
                    }

                }

            }

        });
    }

    public String convertToStr(int ii)
    {
        String str = "";

        switch(ii)
        {
            case 1:str = "1st";break;
            case 2:str = "2nd";break;
            case 3:str = "3rd";break;
            case 4:str = "4th";break;
            case 5:str = "5th";break;
            case 6:str = "6th";break;
            case 7:str = "7th";break;
            case 8:str = "8th";break;
            case 9:str = "9th";break;
            case 10:str = "10th";break;
        }

        return str;

    }


    public void notificationAlert(String title, String msg, String bottomAlert)
    {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setIcon(R.drawable.okcheck1).setNeutralButton(bottomAlert, null).show();
    }

}
