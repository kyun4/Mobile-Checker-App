package com.example.kyun.mobilechecker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class AddCourse extends AppCompatActivity {


    Spinner degreespinner = null;
    Spinner maxyearspinner = null;
    EditText txtCourseDesc = null;
    EditText txtCourseAbbrev = null;
    Button btnBack = null;

    public static Functions func = new Functions();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtCourseAbbrev = (EditText) findViewById(R.id.txtCourseAbbrev);
        txtCourseDesc = (EditText) findViewById(R.id.txtCourseDesc);
        degreespinner = (Spinner) findViewById(R.id.degreespinner);
        maxyearspinner = (Spinner) findViewById(R.id.maxyearspinner);

        btnBack = (Button) findViewById(R.id.btnBack);


        func.loadDegreeSpinner(degreespinner, this);

        func.loadMaxYearSpinner(maxyearspinner, this);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(txtCourseDesc.getText().toString().trim().equals(""))
                {
                   func.snackbar(view,"Course/Program Description must not be empty");
                }
                else
                {

                    func.addCourse(degreespinner,txtCourseDesc, maxyearspinner, txtCourseAbbrev, AddCourse.this);
                    func.notificationAlert("Add Course", "1 Course/Program Added", "OK", AddCourse.this);
                    reset_form();

                }

            }
        });


    }


    public void reset_form()
    {
        txtCourseDesc.setText("");
        txtCourseAbbrev.setText("");
        degreespinner.setSelection(0);
        maxyearspinner.setSelection(0);
    }



}
