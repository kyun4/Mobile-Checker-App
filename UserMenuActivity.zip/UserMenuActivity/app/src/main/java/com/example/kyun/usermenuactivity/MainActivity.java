package com.example.kyun.usermenuactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listview_users;
    Context ctx = this;
    TextView welcome_user;
    ArrayList<Users> users = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listview_users = (ListView) findViewById(R.id.listview_users);
        welcome_user = (TextView) findViewById(R.id.text_currentuser);

        getSupportActionBar().hide();

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        loadusers();

        AdapterView.OnItemClickListener itemclick = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String username =  users.get(position).getUsername();
                int userid = users.get(position).getID();
                prompt_select_user(username,userid);
            }
        };

        listview_users.setOnItemClickListener(itemclick);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent intent = new Intent(MainActivity.this,AddUser.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void prompt_select_user(String username,final int ID)
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(ctx);

        msg.setTitle(""+username+"");
        msg.setMessage("Select this user?");
        msg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                makeCurrentUser(ID);
            }
        });
        msg.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        msg.create().show();
    }

    public void makeCurrentUser(int ID)
    {
        DbaseHelper db = new DbaseHelper(this);
        db.CommandExec("UPDATE tbl_user set is_current = 0");
        db.close();

        db.CommandExec("UPDATE tbl_user set is_current = 1 where user_id = '" + ID + "'");
        db.close();

        loadusers();
    }

    public void loadusers()
    {

        DbaseHelper db = new DbaseHelper(this);

        users.clear();

        Cursor c = db.SelectRaw("SELECT * from tbl_user");
        int record_count = c.getCount();

        if(record_count > 0)
        {
            while(c.moveToNext())
            {
                Users user = new Users();

                user.setID(Integer.parseInt(c.getString(c.getColumnIndex("user_id"))));
                user.setUsername(c.getString(c.getColumnIndex("user_name")));
                user.setOtherdetails(c.getString(c.getColumnIndex("is_current")));
                users.add(user);

                if(user.getOtherdetails().toString().equals("1"))
                {
                    welcome_user.setText("Welcome "+user.getUsername().toString()+" !");
                }
            }
        }

        UsersAdapter userAdapter = new UsersAdapter(ctx,R.layout.item_view, users);
        userAdapter.notifyDataSetChanged();
        listview_users.setAdapter(userAdapter);

        db.close();

    }


}
