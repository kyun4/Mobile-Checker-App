package com.example.kyun.usermenuactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kyun on 2/4/2018.
 */
public class UsersAdapter extends ArrayAdapter<Users> {

    Context ctx;
    List<Users> list_users;

    public UsersAdapter(Context ctx, int resourceid, ArrayList<Users> obj)
    {
        super(ctx,resourceid,obj);
        this.ctx = ctx;
        this.list_users = obj;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = convertView;

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.item_view,null);

        TextView text_username = (TextView) v.findViewById(R.id.text_username);
        TextView text_otherdetails = (TextView) v.findViewById(R.id.text_details);

        ImageView image_edituser = (ImageView) v.findViewById(R.id.edit_user);
        ImageView image_deleteuser = (ImageView) v.findViewById(R.id.delete_user);

        Users user = list_users.get(position);
        String is_current = user.getOtherdetails();


        text_username.setText(user.getUsername().toString());
        text_username.setBackgroundResource(R.drawable.list_item_style);
        text_username.setPadding(20,20,20,20);


        if(is_current.equals("1"))
        {
            text_otherdetails.setVisibility(View.VISIBLE);
            text_otherdetails.setText("Current User");
        }
        else
        {
            text_otherdetails.setVisibility(View.INVISIBLE);
        }

        final String username = user.getUsername().toString();
        final int ID = user.getID();

        image_deleteuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prompt_delete_user(username,ID,v);
            }
        });

        image_edituser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               gotoEdit(username,ID,v);
            }
        });

        return v;
    }

    public void prompt_delete_user(final String username,final int ID,final View vv)
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(ctx);

        msg.setTitle("" + username + "");
        msg.setMessage("Delete this user?");
        msg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                deleteUser(ID, vv.getContext());
                alertmessage("Goodbye " + username + "!", "One Username Removed");

            }
        });
        msg.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        msg.create().show();
    }

    public void gotoEdit(String username, final int ID,final View vv)
    {
        Intent ii = new Intent(getContext(),AddUser.class);
        ii.putExtra("menu_title","Change Username");
        ii.putExtra("username",username);
        ii.putExtra("ID", ID);
        ctx.startActivity(ii);
    }

    public void deleteUser(int ID,Context ctx)
    {
        DbaseHelper db = new DbaseHelper(ctx);
        db.CommandExec("DELETE from tbl_user where user_id = " + ID + "");
        db.close();

    }

    public void alertmessage(String title,String message)
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(ctx);

        msg.setTitle("" + title + "");
        msg.setMessage("" + message + "");
        msg.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        msg.create().show();
    }

}
