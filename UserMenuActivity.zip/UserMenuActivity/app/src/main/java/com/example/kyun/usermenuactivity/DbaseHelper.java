package com.example.kyun.usermenuactivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by JM on 1/24/2018.
 */

public class DbaseHelper extends SQLiteOpenHelper {

    public static  final String DBASE = "dbase.db";

    public DbaseHelper(Context context) {
        super(context, DBASE, null, 3);
        SQLiteDatabase db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL("create table tbl_user ( user_id integer primary key autoincrement," +
                                            " user_name text,is_current integer)");

        db.execSQL("create table tbl_scores ( score_id integer primary key autoincrement," +
                " user_id integer," +
                " stage_id integer," +
                " score integer )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists tbl_questions");
        db.execSQL("drop table if exists tbl_rewards");
        db.execSQL("drop table if exists tbl_stages");
        db.execSQL("drop table if exists tbl_user");
        db.execSQL("drop table if exists tbl_scores");

        onCreate(db);
    }

    //------------COMMAND EXEC------------//
    public void CommandExec(String query) {
        this.getWritableDatabase().execSQL(query);
    }

    //------------COMMAND EXEC PARAM------------//
    public void CommandExecParam(String query, String[] string) {
        this.getWritableDatabase().execSQL(query, string);
    }

    //------------SELECT RAW------------//
    public Cursor SelectRaw(String query) {
        Cursor cursor = this.getReadableDatabase().rawQuery(query, null);
        return cursor;
    }

    public int GetCursorCount (String query) {
        int count = 0;
        Cursor cursor = this.getReadableDatabase().rawQuery(query, null);
        count = cursor.getCount();
        return count;
    }


    //------------SELECT RAW WITH PARAM------------//
    public Cursor SelectRawParam(String query, String[] string) {
        Cursor cursor = this.getReadableDatabase().rawQuery(query, string);
        return cursor;
    }



}
