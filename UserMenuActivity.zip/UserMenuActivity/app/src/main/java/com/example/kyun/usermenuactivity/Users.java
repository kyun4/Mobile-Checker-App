package com.example.kyun.usermenuactivity;

/**
 * Created by kyun on 2/4/2018.
 */
public class Users {

    private int ID;
    private String username;
    private String otherdetails;

    public Users()
    {

    }

    public Users(int ID, String username, String otherdetails)
    {
        this.ID = ID;
        this.username = username;
        this.otherdetails = otherdetails;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getOtherdetails() {
        return otherdetails;
    }

    public void setOtherdetails(String otherdetails) {
        this.otherdetails = otherdetails;
    }
}
