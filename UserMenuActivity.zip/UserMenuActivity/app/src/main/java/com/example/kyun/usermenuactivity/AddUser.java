package com.example.kyun.usermenuactivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddUser extends AppCompatActivity {

    Button btnAddUser,btnCancelUser;
    EditText txtUser;
    TextView menu_title;
    Context ctx = this;

    int userid = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        Intent ii = getIntent();


        btnAddUser = (Button) findViewById(R.id.btnSave);
        btnCancelUser = (Button) findViewById(R.id.btnCancel);

        txtUser = (EditText) findViewById(R.id.text_username);

        menu_title = (TextView) findViewById(R.id.text_menu);

        if(ii.hasExtra("menu_title"))
        {
            menu_title.setText(ii.getStringExtra("menu_title").toString());
            userid = ii.getIntExtra("ID",0);
            txtUser.setText(ii.getStringExtra("username").toString());
        }

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        btnAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = txtUser.getText().toString().trim();
                boolean isexists = checkIfExistUser(username);

                if(userid == 0)
                {
                    if (username.equals("")) {
                        alertmessage_negative("Username is blank", "Enter your Username baby :)");
                    } else if (isexists == true) {
                        alertmessage_negative("Username already exists", "Oops, Try another name");
                    } else {
                        addUserCommand(username);
                        alertmessage("One User Added", "Welcome " + username + " !");
                    }
                }
                else
                {
                    if (username.equals("")) {
                        alertmessage_negative("Username is blank", "Enter your Username baby :)");
                    }
                    else
                    {
                        changeUserCommand(username,userid);
                        alertmessage("Edit Username", "Username Successfully Changed to " + username + " !");
                    }
                }


            }
        });

        btnCancelUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtUser.setText("");
                Intent ii = new Intent(AddUser.this, MainActivity.class);
                startActivity(ii);
            }
        });
    }

    public void changeUserCommand(String username,int ID)
    {
        DbaseHelper db = new DbaseHelper(ctx);

        String query = "UPDATE tbl_user set user_name = '"+username+"' where user_id = '"+ID+"'";
        db.CommandExec(query);
        db.close();
    }

    public void addUserCommand(String username)
    {
        DbaseHelper db = new DbaseHelper(ctx);

        db.CommandExec("UPDATE tbl_user set is_current = 0");
        db.close();

        String query = "INSERT INTO tbl_user (user_name,is_current) values('"+username+"',1)";
        db.CommandExec(query);
        db.close();
    }

    public boolean checkIfExistUser(String username)
    {
        boolean userexist = false;

        DbaseHelper db = new DbaseHelper(ctx);

        Cursor c = db.SelectRaw("SELECT * from tbl_user");
        int record_count = c.getCount();

       if(c.moveToFirst())
       {
           do
           {
                if(username.trim().toLowerCase().equals(c.getString(c.getColumnIndex("user_name")).toString().trim().toLowerCase()))
                {
                    userexist = true;
                }
           }
           while (c.moveToNext());
       }


        db.close();
        return userexist;

    }

    public void alertmessage(String title,String message)
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(ctx);

        msg.setTitle("" + title + "");
        msg.setMessage("" + message + "");
        msg.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(AddUser.this,MainActivity.class);
                startActivity(intent);
            }
        });


        msg.create().show();
    }

    public void alertmessage_negative(String title,String message)
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(ctx);

        msg.setTitle("" + title + "");
        msg.setMessage("" + message + "");
        msg.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        msg.create().show();
    }
}
